importScripts("./jsencrypt.js")
importScripts("./easystar.js")

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}

var objects,checkobjs,points

function encryption(value) {
          var encrypt = new JSEncrypt();
          encrypt.setPublicKey(value[0]);
          var encrypted = encrypt.encrypt(value[2]);

          self.postMessage(encrypted+":"+value[1]);
}

self.onmessage = function(e) {
	var msg=e.data
	last=msg[msg.length-1]
	if(last!="encrypt"){
		objects=msg[0]
		checkobjs=msg[1]
		points=msg[2]
		nonmovable=msg[3]
		mobAI()
	}else{
		msg.pop()
		encryption(msg)
	}
  };




  function mobAI(){
	var temp2
	var tempobj
	for(var ww=0;ww<objects.length;ww++){
		if(objects[ww].split(":")[4]=="mob"){
			tempobj=objects[ww].split(":")
			

			var minDistance = 10000;
			var closest,distance;
			for (var a = 0; a < points.length; a++) {
  				distance = (tempobj[1] - points[a].x) * (tempobj[1] - points[a].x) + (tempobj[2] - points[a].y) * (tempobj[2] - points[a].y);
  				if (distance < minDistance) {
    				minDistance = distance;
    				closest = points[a];
  				}
			}
			if(minDistance<49){

				if(tempobj[1]==closest.x && tempobj[2]==closest.y) continue
				
					var arr=[]
					for(var zz=0;zz<17;zz++){
						var arrx=[]
						for(xx=0;xx<17;xx++){
							arrx.push(0)
						}
						arr.push(arrx)
					}
					for(var ii=0;ii<nonmovable.length;ii++){
						if(((tempobj[1] - nonmovable[ii].split(":")[1]) * (tempobj[1] - nonmovable[ii].split(":")[1]) + (tempobj[2] - nonmovable[ii].split(":")[2]) * (tempobj[2] - nonmovable[ii].split(":")[2]))<64){
							arr[(8+(nonmovable[ii].split(":")[2] - tempobj[2]))][(8+(nonmovable[ii].split(":")[1] - tempobj[1]))]=1
						}
					}
					
					closest.x=8-(tempobj[1]-closest.x)
					closest.y=8-(tempobj[2]-closest.y)
					
					easystarf(tempobj,arr,closest,ww)

			}else{
				var temprand=getRandomInt(1,5)
				if(temprand==1){
					self.postMessage("movemob:"+tempobj[0]+":"+(Number(tempobj[1])-1)+":"+tempobj[2])

					temp2=objects[ww].split(":")
					temp2[1]=Number(temp2[1])-1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==2){
					self.postMessage("movemob:"+tempobj[0]+":"+(Number(tempobj[1])+1)+":"+tempobj[2])

					temp2=objects[ww].split(":")
					temp2[1]=Number(temp2[1])+1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==3){
					self.postMessage("movemob:"+tempobj[0]+":"+tempobj[1]+":"+(Number(tempobj[2])-1))


					temp2=objects[ww].split(":")
					temp2[2]=Number(temp2[2])-1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==4){
					self.postMessage("movemob:"+tempobj[0]+":"+tempobj[1]+":"+(Number(tempobj[2])+1))

					temp2=objects[ww].split(":")
					temp2[2]=Number(temp2[2])+1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
			}
			objects[ww]=objects[ww].split(":")
			objects[ww][4]="mob1"
			objects[ww]=objects[ww].join(":")
			self.postMessage("updateobjects:"+objects[ww])
			
		}
	}

}

easystarf=function(tempobj,arr,closest,ww){

	const easystar = new EasyStar.js();
	easystar.setGrid(arr);
	easystar.setAcceptableTiles([0]);
	easystar.findPath(8, 8, Number(closest.x), Number(closest.y), function( path ) {
		if (path === null) {
			var temprand=getRandomInt(1,5)
				if(temprand==1){
					self.postMessage("movemob:"+tempobj[0]+":"+(Number(tempobj[1])-1)+":"+tempobj[2])

					temp2=objects[ww].split(":")
					temp2[1]=Number(temp2[1])-1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==2){
					self.postMessage("movemob:"+tempobj[0]+":"+(Number(tempobj[1])+1)+":"+tempobj[2])

					temp2=objects[ww].split(":")
					temp2[1]=Number(temp2[1])+1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==3){
					self.postMessage("movemob:"+tempobj[0]+":"+tempobj[1]+":"+(Number(tempobj[2])-1))

					temp2=objects[ww].split(":")
					temp2[2]=Number(temp2[2])-1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
				if(temprand==4){
					self.postMessage("movemob:"+tempobj[0]+":"+tempobj[1]+":"+(Number(tempobj[2])+1))

					temp2=objects[ww].split(":")
					temp2[2]=Number(temp2[2])+1
					checkobjs.push(0+":"+0+":"+temp2.join(":"))
					self.postMessage("updatecheckobjs:"+checkobjs)
					}
		} else {
			self.postMessage("movemob:"+tempobj[0]+":"+(Number(tempobj[1])-(8-Number(path[1].x)))+":"+(Number(tempobj[2])-(8-Number(path[1].y))))


			temp2=objects[ww].split(":")
			temp2[1]=(Number(tempobj[1])-(8-Number(path[1].x)))
			temp2[2]=(Number(tempobj[2])-(8-Number(path[1].y)))
			checkobjs.push(0+":"+0+":"+temp2.join(":"))
			self.postMessage("updatecheckobjs:"+checkobjs)
		}
	});
	easystar.calculate();
}