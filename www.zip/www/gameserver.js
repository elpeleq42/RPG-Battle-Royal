var maxnumberofplayers,admpassword,serverPort,initialgold,upspeedmap,serverpass,map


if(localStorage.getItem("stuff")!=null){
var tempstuff=localStorage.stuff;tempstuff=tempstuff.split("\n")

maxnumberofplayers=[6]
admpassword=tempstuff[5]  
serverPort=tempstuff[4]  	
initialgold=tempstuff[3]   
upspeedmap=tempstuff[2]	  
serverpass=tempstuff[1]      
map=tempstuff[0]			
alert(1)
}else{
//Server configs:////////////////////
maxnumberofplayers=mxplayers//
admpassword=adminpassword  //
serverPort=servportnumb  	//
initialgold=initgold     //
upspeedmap=upspeed	  //
serverpass=servpass      //
map=servmap				//
/////////////////////////////
}



//////////////////////////////////////////////
const ws = require("./lib/index.js")
const crypt = require('crypto')
var nonmovable = []
var playercounter= new Uint8Array(101).fill(0)
var playernames = new Array(101).fill("")
var giveID=0
var disconnectthis
var string
var numberofplayers=0
var serverfull=false
var playersalive=0
var serverlock=false
var checkendgame
var highestid=0
var objectcounter=0
var objects=[]
var checkobjs=[]
var temp
var timelapse=undefined
var arrbuffer=undefined
var tobeuploaded=[]
var banlist=[]



if(map!=="default" && !map.startsWith("http")){
	const fs   = require('fs')  
	var file = process.argv[2],
	map = fs.readFileSync(servmap);
	if(upspeedmap!=0){

		map=new Buffer(map)
		breakup=Math.ceil(map.length/(102400*upspeedmap))
		forsize=Math.ceil(map.length/breakup)
		arrbuffer=new Array(breakup)
		for(var i=0;i<breakup;i++){
			arrbuffer[i]=Buffer.allocUnsafe(forsize)
			map.copy(arrbuffer[i],0,i*forsize,(i+1)*forsize)
			arrbuffer[i]=arrbuffer[i]
		}
		map="filecustom"


	}else{
		var map="filecustom"
		buffer=new Buffer(map).toString('binary')
	}
}


function mapupload(tobindex,time){

	setTimeout(()=>{
		var tempslice
		if(tobeuploaded[tobindex]==undefined && tobeuploaded.length>0){
			tobindex=0
			for(var u=0;u<server.connections.length;u++){
			if(server.connections[u].tempID==tobeuploaded[tobindex][0]){
				if(tobeuploaded.length>=5){
					server.connections[u].send(Buffer.concat(arrbuffer[tobeuploaded[tobindex][1]]).toString("binary"))
					tobeuploaded[tobindex][1]=tobeuploaded[tobindex][1]+1
				}else{
					tempslice=arrbuffer.slice(tobeuploaded[tobindex][1],tobeuploaded[tobindex][1]+Math.round(5/tobeuploaded.length))
					if(tempslice.length===0){
						tobeuploaded[tobindex][1]=breakup
					}else{
						server.connections[u].send(Buffer.concat(tempslice).toString("binary"))
						tobeuploaded[tobindex][1]=tobeuploaded[tobindex][1]+Math.round(5/tobeuploaded.length)
					}
					
				}
				
				if(tobeuploaded[tobindex][1]==breakup){
					tobeuploaded.splice(tobindex,1);
					server.connections[u].send("finished");
					server.connections[u].close()
				}
				if(tobeuploaded.length>0){ 
					if(tobeuploaded.length>=5){
						mapupload(tobindex++,100)
					}else{
						mapupload(tobindex++,Math.ceil(500/tobeuploaded.length))
					}
				}
				break
				return
			}
		}
		tobeuploaded.splice(tobindex,1)
			
		}else if(tobeuploaded.length==0){
			return
		}
		for(var u=0;u<server.connections.length;u++){
			if(server.connections[u].tempID==tobeuploaded[tobindex][0]){
				if(tobeuploaded.length>=5){
					server.connections[u].send(Buffer.concat(arrbuffer[tobeuploaded[tobindex][1]]).toString("binary"))
					tobeuploaded[tobindex][1]=tobeuploaded[tobindex][1]+1
				}else{
					tempslice=arrbuffer.slice(tobeuploaded[tobindex][1],tobeuploaded[tobindex][1]+Math.round(5/tobeuploaded.length))
					if(tempslice.length===0){
						tobeuploaded[tobindex][1]=breakup
					}else{
						server.connections[u].send(Buffer.concat(tempslice).toString("binary"))
						tobeuploaded[tobindex][1]=tobeuploaded[tobindex][1]+Math.round(5/tobeuploaded.length)
					}
					
				}
				
				if(tobeuploaded[tobindex][1]==breakup){
					tobeuploaded.splice(tobindex,1);
					server.connections[u].send("finished");
					server.connections[u].close()
				}
				if(tobeuploaded.length>0){ 
					if(tobeuploaded.length>=5){
						mapupload(tobindex++,100)
					}else{
						mapupload(tobindex++,Math.ceil(500/tobeuploaded.length))
					}
				}
				break
				return
			}
		}
		tobeuploaded.splice(tobindex,1)
		
	},time)

}

//////////////////////////////////////////////

var workerr = new Worker("encrypter.js");
workerr.onmessage = function(e) {
	var msg=e.data
	if(msg.startsWith("movemob")){
		broadcast(msg)
	}else if(msg.startsWith("updateobjects")){

		msg=msg.split(":");msg.shift();
		for(var i=0;i<objects.length;i++){
			if(objects[i].split(":")[0]==msg[0]){
				objects[i]=msg.join(":")
			}
		}
	}else if(msg.startsWith("updatecheckobjs")){
		msg=msg.split(":");msg.shift();msg=msg.join(":").split(",")
		checkobjs=msg.filter(item => item)

	}else{
		msg=msg.split(":")
		var i=msg.slice(msg.length-1,msg.length).join(":")
		msg = msg.slice(0,msg.length-1).join(":")
		server.connections[i].send("password:"+msg)
		server.connections[i].send(encrypt("id:"+server.connections[i].playerid,server.connections[i].playerdecode))
	}

	
 }
  

function encrypt(text, password){

	 var cipher = crypt.createCipher('aes-128-cbc',password)
	 var crypted = cipher.update(text,'utf8','hex')
	 crypted += cipher.final('hex');
	
	 return crypted;
}
 
function decrypt(text, password){

  	var decipher = crypt.createDecipher('aes-128-cbc',password)
  	var dec = decipher.update(text,'hex','utf8')
  	dec += decipher.final('utf8');

  	return dec;
}

function generatepass(length) {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < length; i++){
      text += possible.charAt(Math.floor(Math.random() * possible.length))}
	text=text.toString()

  return text;
}


var server = ws.createServer(function (connection) {
	for(var i=banlist.length,con=connection.headers.origin.split("//")[1];i--;){
		if(con==banlist[i][1]){ 
			connection.close()
			return
		}
	}
	connection.on("binary", function () {
		connection.close()
	})


if(numberofplayers>=maxnumberofplayers){
			connection.send("serverfull")
			connection.close()
			return
		}

	connection.playerid = null
	connection.playername = null
	connection.playerdecode = null
	connection.admin=false
	connection.muted=false
	connection.alive=true
	connection.x=undefined
	connection.y=undefined
	connection.playerip=undefined
	connection.msgcounter=0
	if(serverpass!==undefined){
		connection.sentpass=false
	}

	connection.on("text", function (str) {
		
		connection.postMessage++
		if(connection.postMessage>50) connection.close()

		if(str=='undefined'){
			return
		}else if(connection.playerdecode!==null){
			str1=decrypt(String(str),connection.playerdecode)
		}else{
			if(connection.postMessage>5) connection.close()
			str1=str
		}
		
		if(str==="ping"){
			if(serverpass!==undefined){
				connection.sendText("totalplayers:"+numberofplayers+"/"+maxnumberofplayers+":locked")
			}else{
				connection.sendText("totalplayers:"+numberofplayers+"/"+maxnumberofplayers)
			}
			connection.close()

		}
		else if(str==="map?"){
			if(connection.sentpass==false){
				connection.send("pass?")
				return
			}

			if(map.startsWith("http")){
				connection.send(map)
			}else if(arrbuffer!=undefined){
				connection.tempID=getRandomInt(0,999999)
				tobeuploaded.push([connection.tempID,0])
				if(tobeuploaded.length==1) mapupload(0,500)

			}else{
				connection.send(map)
				connection.close()
			}
			 
            
		}else if(str==serverpass){
			if(map.startsWith("http")){
				connection.send(map)
			}else if(arrbuffer!=undefined){
				connection.tempID=getRandomInt(0,999999)
				tobeuploaded.push([connection.tempID,0])
				if(tobeuploaded.length==1) mapupload(0,500)

			}else{
				connection.send(map)
				connection.close()
			}
		}

		else if(str1==="checkping"){
			connection.send(encrypt("checked", connection.playerdecode))
		}

		else if (connection.playerid === null && numberofplayers<100) {
			if(!str1.startsWith("pass") ||( (str1.split(":").length<2 && serverpass!==undefined) || (str1.split(":")[2]!=serverpass && serverpass!==undefined))){
				connection.close()
				return
			}
			str1=str1.split(":")
			str1.shift()
			connection.sentpass=true
			str1=str1[0]

			connection.playerdecode=generatepass(50)
			workerr.postMessage([str1,(server.connections.length-1),connection.playerdecode,"encrypt"]);

			for(var i=1;i<=101;i++){
					if(playercounter[i]===0){
						giveID=i
						playercounter[i]=1
						break
					}
				}
			connection.playerid = giveID
			
		}else if(str1.startsWith("name") ){
			str1=str1.split(":")
				var name=str1[1]
				for(var i=banlist.length,con=str1[2];i--;){
					if(con==banlist[i][0]){ 
						connection.close()
						return
					}
				}
				connection.playerip=str1[2]
				for(var zz=0;zz<playernames.length;zz++){
					if(playernames[zz]===name){
					name=name+zz
					}
				}

				connection.playername=name
				

			playernames[giveID]=connection.playername

			numberofplayers++

			playersalive++

			highestid++
			for(var u=1;u<highestid;u++){
				connection.send(encrypt("spawn:"+(100+u)+":"+playernames[u], connection.playerdecode))
				
			}
			for(var o=1;o<highestid;o++){
				if(playercounter[o]===0){
					broadcast("dead:"+o)
				}
			}	
			
			for(var i=0;i<objects.length;i++){
				objects=objects.filter(Boolean)
				temp=objects[i];temp=temp.toString().split(":")
				connection.send(encrypt("build:"+temp[1]+":"+temp[2]+":"+temp[3]+":"+temp[0]+":"+str1[4]+":"+str1[5], connection.playerdecode))
				
			}

			broadcast("spawn:"+(100+giveID)+":"+name)
			
			broadcast("chat::"+name+" has joined.")
			
			broadcast("eventid:"+giveID)
			connection.send(encrypt("receivegold:"+initialgold,connection.playerdecode))
			if(numberofplayers>1 && serverlock===false && map=="default" ){
				begingame()
			}
			if(serverlock===true && map==="default"){
				connection.send(encrypt("roundstarted", connection.playerdecode))
				connection.alive=false
			}

			}
		else if(str1.startsWith("arrow")){
			var str2=str1.split(":")
			if(Math.abs(str2[1]-connection.x)>2 || Math.abs(str2[2]-connection.y)>2) {connection.close();return}
			broadcast(str1)
		}
		else if(str1.startsWith("build")){
			str1=str1.split(":")
			if(str1[1]==1){
				broadcast("build:"+connection.x+':'+(Number(connection.y)+1)+":"+str1[2]+":"+objectcounter+":"+str1[3]+":"+str1[4])
					objects[objectcounter]=objectcounter+":"+connection.x+":"+(Number(connection.y)+1)+":"+str1[2]+":"+str1[3]+":"+str1[4]
					objectcounter++
			}else if(str1[1]==2){
				broadcast("build:"+(Number(connection.x)-1)+':'+connection.y+":"+str1[2]+":"+objectcounter+":"+str1[3]+":"+str1[4])
					objects[objectcounter]=objectcounter+":"+(Number(connection.x)-1)+":"+connection.y+":"+str1[2]+":"+str1[3]+":"+str1[4]
					objectcounter++
			}else if(str1[1]==3){
				broadcast("build:"+(Number(connection.x)+1)+':'+connection.y+":"+str1[2]+":"+objectcounter+":"+str1[3]+":"+str1[4])
					objects[objectcounter]=objectcounter+":"+(Number(connection.x)+1)+":"+connection.y+":"+str1[2]+":"+str1[3]+":"+str1[4]
					objectcounter++
			}else if(str1[1]==4){
				broadcast("build:"+connection.x+':'+(Number(connection.y)-1)+":"+str1[2]+":"+objectcounter+":"+str1[3]+":"+str1[4])
					objects[objectcounter]=objectcounter+":"+connection.x+":"+(Number(connection.y)-1)+":"+str1[2]+":"+str1[3]+":"+str1[4]
					objectcounter++
			}
		}
		else if(str1.startsWith("tpevent")){
			broadcast(str1)
			connection.x=str1.split(":")[1]
			connection.y=str1.split(":")[2]
		}
		else if(str1.startsWith("animation")){
			broadcast(str1)
		}
		else if(str1.startsWith("magic")){
			var str2=str1.split(":")
			if(Math.abs(str2[1]-connection.x)>2 || Math.abs(str2[2]-connection.y)>2) {connection.close();return}
			broadcast(str1)
		}
		else if(str1.startsWith("opened")){
			broadcast(str1)
		}
		else if(str1.startsWith("chest")){
			broadcast(str1+":"+objectcounter)
			str1=str1.split(":")
			objects[objectcounter]=objectcounter+":"+str1[2]+":"+str1[3]+":"+str1[1]
			objectcounter++
		}
		else if(str1.startsWith("flashlight")){
			if((connection.playerid+100)!=str1.split(":")[1]){connection.close();return}
			broadcast(str1)
		}

		else if(str1.startsWith("destroy")){
			objects=objects.filter(Boolean)
			for(var i=0;i<objects.length;i++){
				temp=objects[i];temp=temp.split(":")
				if(temp[0]==str1.split(":")[1] && temp[1]==str1.split(":")[2] && temp[2]==str1.split(":")[3]){
					objects.splice(i, 1);
					broadcast(str1)

					for(var u=0;u<nonmovable.length;u++){
						if(nonmovable[u].split(":")[0]==str1.split(":")[1]) nonmovable.splice(u,1)
						break
					}
					break;
				}	
			}

		}
		else if(str1.startsWith("dead")){
			if(str1.split(":")[1]!=connection.playerid) {connection.close();return}
			broadcast(str1)
			playersalive--
			for(var i=0;i<server.connections.length;i++){
				if(Number(server.connections[i].playerid)==Number(str1.split(":")[1])){
					server.connections[i].alive=false
				}
			}

		}
		else if(str1.startsWith("through")){
			broadcast(str1)
		}
		else if(str1.startsWith("sendgold")){
			var idtosend=str.split(":")
			idtosend=idtosend[1]
			for(var i=0;i<server.connections.length;i++){
				if(Number(server.connections[i].playerid)===Number(idtosend)){
					server.connections[i].send(encrypt("receivegold:"+getRandomInt(30,51),server.connections[i].playerdecode))
					break
				}
			}
			
		}
		else if(str1.startsWith("confirmed")){
			str1=str1.split(":")


			for(var i=0;i<checkobjs.length;i++){
				var tempobj1=checkobjs[i].split(":")

				if(tempobj1[2]==str1[1] && tempobj1[3]==str1[2] && tempobj1[4]==str1[3]){
					tempobj1[0]=Number(tempobj1[0])+1
					if(tempobj1[0]==3 || tempobj1[0]>=Math.round(numberofplayers/2)){
						for(var o=0;o<objects.length;o++){
							var tempobj2=objects[o].split(":")
							if(tempobj1[2]==tempobj2[0]){

								tempobj1.shift();tempobj1.shift()
								tempobj1[4]="mob"
								for(var u=0;u<nonmovable.length;u++){
									if(nonmovable[u].split(":")[1]==tempobj1[1] && nonmovable[u].split(":")[2]==tempobj1[2]){ 
										nonmovable.splice(u,1)
									}
								}
								objects[o]=tempobj1.join(":")
								checkobjs[i]=""
								
								break
							}

						}
					}else{
						checkobjs[i]=tempobj1
					}
					break
				}
			}
			checkobjs.filter(item => item)
			
			
		}else if(str1.startsWith("denied")){
			str1=str1.split(":")

			for(var i=0;i<checkobjs.length;i++){
				var tempobj1=checkobjs[i].split(":")

				if(tempobj1[2]==str1[1] && tempobj1[3]==str1[2] && tempobj1[4]==str1[3]){
					tempobj1[1]=Number(tempobj1[1])+1
					if(tempobj1[1]==3 || tempobj1[1]>=Math.round(numberofplayers/2)){
						checkobjs[i]=""
						for(var o=0;o<objects.length;o++){
							var tempobj2=objects[o].split(":")
							if(tempobj1[2]==tempobj2[0]){
								tempobj2[4]="mob"
								objects[o]=tempobj2.join(":")
								checkobjs[i]=""
								nonmovable.push((objectcounter*1000)+":"+str1[2]+":"+str1[3])
											
								break
							}
						}
					}else{
						checkobjs[i]=tempobj1
					}
					break
				}
			}
			checkobjs.filter(item => item)
			
		}
		else if(str1.startsWith("chat:")){
			var str2=str1.split(":")
			str2=str2.splice(1,str2.length)
			str2=str2.join(":")
			if(str2.startsWith("/adm")){
				str2=str2.split(" ").splice(1,str2.length).join(" ")
				if(admpassword!==undefined && str2==admpassword){
					connection.adm=true
					connection.send(encrypt("chat::You're now admin!",connection.playerdecode))
				}
			}
			else if(str2.startsWith("/list")){
				server.connections.forEach(function (connectionn) {
					if(connectionn.playerid!==null){
						connection.send(encrypt("chat::>ID:"+connectionn.playerid+", name:"+connectionn.playername,connection.playerdecode))
					}

				})
			}
			else if(str2.startsWith("/kick") && connection.adm===true){
				str2=str2.split(" ")
				server.connections.forEach(function (connectionn) {

					if(connectionn.playerid==str2[1]){
						broadcast("chat::>"+connectionn.playername+" has been kicked.")
						connectionn.close()
					}
				})
			}
			else if(str2.startsWith("/ban") && connection.adm===true){
				str2=str2.split(" ")
				server.connections.forEach(function (connectionn) {

				if(connectionn.playerid==str2[1]){
					broadcast("chat::>"+connectionn.playername+" has been banned.")
					connectionn.close()
					banlist.push([connectionn.playerip,connectionn.headers.origin.split("//")[1]])
				}
				})
			}else if(str2.startsWith("/closeserver") && connection.adm===true){
				str2=str2.split(" ")
				server.connections.forEach(function (connectionn) {
					connectionn.sentpass=true
				})
				serverpass=str2[1]
				connection.sendText(encrypt("chat::>Server is now password closed.",connection.playerdecode))
			}else if(str2.startsWith("/openserver") && connection.adm===true){
				serverpass=undefined
				connection.sendText(encrypt("chat::>Server is now open to everyone.",connection.playerdecode))
			}else if(str2==="/begin" && connection.adm===true){
				begingame()
			}else if(str2==="/update" && connection.adm===true){
				str2=str2.split(" ")
				function download(url, dest, callback) {
					if(url.startsWith("https")){var http = require('https');}
					else{var http = require('http')}
					var fs=require("fs")
					var file = fs.createWriteStream(dest);
					var request = http.get(url, function (response) {
						response.pipe(file);
						file.on('finish', function () {
							file.close(callback); // close() is async, call callback after close completes.
						});
						file.on('error', function (err) {
							fs.unlink(dest); // Delete the file async. (But we don't check the result)
							if (callback)
							callback(err.message);
						});
					});
				}
				download(str2[1],"/files.zip",function(){
					var AdmZip = require('./www/admzip/adm-zip.js');
    				var zip = new AdmZip('./files.zip'); 
    				var zipEntries = zip.getEntries(); 
    				zip.extractAllToAsync('./',true,function(){
    					for(var i=server.connections.length;i--;){
    						server.connections[i].close()
    					}
    					server.close(function(){
    						localStorage.setItem("stuff",[servmap,servpass,upspeed,initgold,servportnumb,adminpassword,mxplayers].join("\n"))
    						location.reload()
    					})
    					
    				})
				})

			}else if(str2.startsWith("/mute") && connection.adm===true){
				str2=str2.split(" ")
				
				server.connections.forEach(function (connectionn) {
				if(String(connectionn.playerid)===String(str2[1]))
				{

					connectionn.send(encrypt("chat::You have been muted for "+str2[2]+" seconds.",connectionn.playerdecode))
					connection.send(encrypt("chat::>Player id "+str2[1]+" has been muted for "+str2[2]+" seconds.",connection.playerdecode))
					connectionn.muted=true
					str2[2]=Number(str2[2])*1000
					eval(`setTimeout(()=>{
							
						server.connections.forEach(function (connectionn) {

						if(String(connectionn.playerid)===String(`+str2[1]+`))
						{
							connectionn.muted=false
						}
						})

					},`+Number(str2[2])+`)`)
				}
				})
			}
			else if(connection.muted!==true && connection.playerid!==null && str2.startsWith("/")==false){
				broadcast("chat:"+connection.playername+":"+str2)
			}

		}
		else if(serverpass!==undefined && connection.sentpass!=false && serverlock==true){
			connection.x=str1.split(":")[0]
			connection.y=str1.split(":")[1]
			broadcast("update:"+connection.playerid+":"+str1)
		}else if(serverpass===undefined && serverlock==true){
			connection.x=str1.split(":")[0]
			connection.y=str1.split(":")[1]
			broadcast("update:"+connection.playerid+":"+str1)
		}
		 		

	})



	connection.on("close", function(aa){

if(connection.playername!==null){
broadcast("chat::"+connection.playername+" has left.")
	var lasthighestid=highestid
	for(var a=0;a<=lasthighestid;a++){
		if(playercounter[a]===1){
		highestid=a
		}
	}
playernames[connection.playerid]=""
		numberofplayers--
		if(connection.alive==true){
			playersalive--
		}
		disconnectthis=Number(connection.playerid)
		playercounter[disconnectthis]=0
		broadcast("dead:"+connection.playerid)
if(playersalive<1 && numberofplayers<1){
	serverlock=false

}

}


	})




}).listen(serverPort) ////port the server is listening to.

setInterval(()=>{
	for(var i=0;i<server.connections.length;i++){
		server.connections[i].msgcounter=0
	}
},1000)


function broadcast(str) {
	for(var z=server.connections.length;z--;){
		if(server.connections[z].playerdecode!==null){
			server.connections[z].sendText(encrypt(str, server.connections[z].playerdecode))
		}
	}
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}

function createobject(x,y,objid,extra,tp,playerid){
	if(!extra) extra=""
	if(!tp) tp=""
	if(!playerid) playerid=""
	broadcast("build:"+x+":"+y+":"+objid+":"+objectcounter+":"+extra+":"+tp+":"+playerid)
	objects.push(objectcounter+":"+x+":"+y+":"+objid+":"+extra+":"+tp+":"+playerid)
	nonmovable.push(objectcounter+":"+x+":"+y)
	objectcounter++
}

begingame=function(){
if(timelapse==undefined){
	var light=100
	var modifier=-1
	timelapse=setInterval(()=>{
		if(light===100){
			modifier=-1
		}else if(light===25){
			modifier=1
		}
		light=light+modifier
		broadcast("server:timelapse:"+light)
	},1500)
}
objects=[]
checkobjs=[]
for(var i=0;i<nonmovable.length;i++){
	if(nonmovable[i].split(":")[0]<=objectcounter){
		nonmovable[i]=""
	}
}
nonmovable.filter(item => item)
objectcounter=0;
for(var i=0;i<server.connections.length;i++){
	server.connections[i].alive=true
}

if(checkendgame){
	clearInterval(checkendgame)
}



						broadcast("reset")
						for(var u=1;u<highestid;u++){
						broadcast("eventid:"+u)
						if(playercounter[u]===0){
								broadcast("dead:"+u)
							}
						}
	broadcast("gamewillbegin")
					setTimeout(()=>{



if(getRandomInt(1,4)>1){createobject(15,29,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(22,20,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(24,11,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(22,42,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(59,10,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(49,26,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(41,33,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(63,31,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(61,43,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(71,51,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(56,68,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(20,78,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(47,79,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(79,58,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(86,41,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(99,23,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(52,97,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(41,39,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(75,15,getRandomInt(4,9))}
if(getRandomInt(1,4)>1){createobject(68,41,getRandomInt(4,9))}

spawnmobs=setTimeout(()=>{
	if(getRandomInt(1,3)>1){createobject(52,34,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(68,41,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(20,78,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(47,79,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(99,23,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(71,51,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(22,42,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(41,33,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(79,58,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(15,29,18,"mob")}
	if(getRandomInt(1,3)>1){createobject(41,39,18,"mob")}
},5000)

setInterval(()=>{
	var points=[]
	for(var i=0;i<server.connections.length;i++){
		points.push({x:server.connections[i].x,y:server.connections[i].y})
	}

	var uniqueArray = [];
	for(i=0; i < nonmovable.length; i++){
	    if(uniqueArray.indexOf(nonmovable[i]) === -1) {
	        uniqueArray.push(nonmovable[i]);
	    }
	}
	workerr.postMessage([objects,checkobjs,points,uniqueArray])
	nonmovable=uniqueArray
},250)

				broadcast("begin")
				serverlock=true
				checkendgame=setInterval(()=>{
					if(playersalive<2){
						clearInterval(spawnmobs)
						playersalive=numberofplayers
						broadcast("reset")
						for(var u=1;u<highestid;u++){
						broadcast("eventid:"+u)
						if(playercounter[u]===0){
								broadcast("dead:"+u)
							}
						}

						clearInterval(checkendgame)
						serverlock=false
						if(numberofplayers>1 && map==="default"){
							begingame()
						}
					}

				},1001)
			},3000)
}


console.log("Server running!")